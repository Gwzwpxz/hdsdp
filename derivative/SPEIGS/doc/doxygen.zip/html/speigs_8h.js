var speigs_8h =
[
    [ "speigs_analyze", "speigs_8h.html#a666fdf8eea0a65f440e4d6df85665571", null ],
    [ "speigs_factorize", "speigs_8h.html#a75dad0755ced826913f2166e5f117217", null ]
];