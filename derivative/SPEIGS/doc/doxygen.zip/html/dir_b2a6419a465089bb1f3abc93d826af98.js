var dir_b2a6419a465089bb1f3abc93d826af98 =
[
    [ "example.c", "example_8c.html", "example_8c" ],
    [ "example.h", "example_8h_source.html", null ],
    [ "speigs.c", "speigs_8c.html", "speigs_8c" ],
    [ "speigs.h", "speigs_8h.html", "speigs_8h" ],
    [ "spinfo.h", "spinfo_8h.html", "spinfo_8h" ]
];