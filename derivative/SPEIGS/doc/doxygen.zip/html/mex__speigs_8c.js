var mex__speigs_8c =
[
    [ "mexFunction", "mex__speigs_8c.html#a6a215cbfde54f82a3ce599228fc3fce5", null ],
    [ "print_mtype", "mex__speigs_8c.html#a1078e1a5eae145e00177438f5695069c", null ]
];