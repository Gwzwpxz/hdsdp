var spinfo_8h =
[
    [ "ROOT", "spinfo_8h.html#a77988da40e9a35da51ea0e8943ebbd4a", null ],
    [ "dsyevr", "spinfo_8h.html#add604d01bb486ebe678746dde0f178dd", null ]
];