var searchData=
[
  ['_5fmexinittermtableentry_0',['_mexInitTermTableEntry',['../struct__mex_init_term_table_entry.html',1,'']]],
  ['_5fmexlocalfunctiontable_1',['_mexLocalFunctionTable',['../struct__mex_local_function_table.html',1,'']]]
];
