var searchData=
[
  ['root_0',['ROOT',['../spinfo_8h.html#a77988da40e9a35da51ea0e8943ebbd4a',1,'spinfo.h']]]
];
