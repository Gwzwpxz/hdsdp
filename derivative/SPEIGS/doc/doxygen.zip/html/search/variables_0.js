var searchData=
[
  ['speig_5froutines_0',['speig_routines',['../speigs_8c.html#a22a48d39ff077c490e5856be2c609dc3',1,'speigs.c']]]
];
