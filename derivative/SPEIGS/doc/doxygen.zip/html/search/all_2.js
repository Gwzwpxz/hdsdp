var searchData=
[
  ['main_0',['main',['../example_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'example.c']]],
  ['mex_5fspeigs_2ec_1',['mex_speigs.c',['../mex__speigs_8c.html',1,'']]],
  ['mexfunction_2',['mexFunction',['../mex__speigs_8c.html#a6a215cbfde54f82a3ce599228fc3fce5',1,'mex_speigs.c']]]
];
