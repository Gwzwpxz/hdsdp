var searchData=
[
  ['speig_5fget_5ffactorize_5fspace_0',['speig_get_factorize_space',['../speigs_8c.html#a8de06df8300803babae7d5e8c157eb29',1,'speigs.c']]],
  ['speig_5froutines_1',['speig_routines',['../speigs_8c.html#a22a48d39ff077c490e5856be2c609dc3',1,'speigs.c']]],
  ['speigs_2',['SPEIGS',['../md___users_gaowenzhi__desktop_public__s_p_e_i_g_s__r_e_a_d_m_e.html',1,'']]],
  ['speigs_2ec_3',['speigs.c',['../speigs_8c.html',1,'']]],
  ['speigs_2eh_4',['speigs.h',['../speigs_8h.html',1,'']]],
  ['speigs_5fanalyze_5',['speigs_analyze',['../speigs_8c.html#a666fdf8eea0a65f440e4d6df85665571',1,'speigs_analyze(spint *Ap, spint *Ai, double *Ax, spint *dim, spint *iwork, spint *liwork, double *work, spint *lwork, spint *type, spint *sn, double tol, double gthresh):&#160;speigs.c'],['../speigs_8h.html#a666fdf8eea0a65f440e4d6df85665571',1,'speigs_analyze(spint *Ap, spint *Ai, double *Ax, spint *dim, spint *iwork, spint *liwork, double *work, spint *lwork, spint *type, spint *sn, double tol, double gthresh):&#160;speigs.c']]],
  ['speigs_5fcompute_5fsubmat_6',['speigs_compute_submat',['../speigs_8c.html#acb0343fe2524a11d6be29dc1da50cc17',1,'speigs.c']]],
  ['speigs_5ffactorize_7',['speigs_factorize',['../speigs_8c.html#a75dad0755ced826913f2166e5f117217',1,'speigs_factorize(spint *Ap, spint *Ai, double *Ax, spint *dim, spint *aiwork, double *awork, spint *type, spint *sn, spint *iwork, spint *liwork, double *work, spint *lwork, double *evals, double *evecs, spint *rank, double tol):&#160;speigs.c'],['../speigs_8h.html#a75dad0755ced826913f2166e5f117217',1,'speigs_factorize(spint *Ap, spint *Ai, double *Ax, spint *dim, spint *aiwork, double *awork, spint *type, spint *sn, spint *iwork, spint *liwork, double *work, spint *lwork, double *evals, double *evecs, spint *rank, double tol):&#160;speigs.c']]],
  ['speigs_5ffactorize_5fdense_8',['speigs_factorize_dense',['../speigs_8c.html#aa1c450890a676cb93c8680cb119823b8',1,'speigs.c']]],
  ['speigs_5ffactorize_5fdiag_9',['speigs_factorize_diag',['../speigs_8c.html#a37fe00bbc2815de7fc6e775eddc8c8dd',1,'speigs.c']]],
  ['speigs_5ffactorize_5fgeneral_10',['speigs_factorize_general',['../speigs_8c.html#a5337679209a4396a68fb088657c5febf',1,'speigs.c']]],
  ['speigs_5ffactorize_5frankone_11',['speigs_factorize_rankone',['../speigs_8c.html#ae630932728384be548a0ff8a1980b4e0',1,'speigs.c']]],
  ['speigs_5ffactorize_5fsparse_12',['speigs_factorize_sparse',['../speigs_8c.html#a982d9abb409ab8d1278c06ffc00023d1',1,'speigs.c']]],
  ['speigs_5ffactorize_5ftwo_13',['speigs_factorize_two',['../speigs_8c.html#aed1224cb9513f48ebb648353d58d4ac8',1,'speigs.c']]],
  ['speigs_5ffactorize_5fzero_14',['speigs_factorize_zero',['../speigs_8c.html#ad6dddc04c0a2e24a22e71e3fcf8ae43f',1,'speigs.c']]],
  ['speigs_5fis_5fdiag_15',['speigs_is_diag',['../speigs_8c.html#a7c7535c2243b14fd6bd6857a9414d0df',1,'speigs.c']]],
  ['speigs_5fis_5frankone_16',['speigs_is_rankone',['../speigs_8c.html#ae5addf8aed6c4b2bc93d0a42813579d3',1,'speigs.c']]],
  ['spinfo_2eh_17',['spinfo.h',['../spinfo_8h.html',1,'']]]
];
