var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "adpcg.c", "adpcg_8c.html", "adpcg_8c" ],
    [ "adpcg.h", "adpcg_8h.html", "adpcg_8h" ]
];