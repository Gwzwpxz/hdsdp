var adpcg_8c =
[
    [ "cg_alloc", "adpcg_8c.html#a6b92dfb6d54a82b6f8c1f4e7e5b765ce", null ],
    [ "cg_decision", "adpcg_8c.html#a25344647e8c828d40c7584dd36675279", null ],
    [ "cg_finish", "adpcg_8c.html#ab2db786b0a4ff73bc1090eb786f07b3a", null ],
    [ "cg_free", "adpcg_8c.html#a01232c348051ba27254a883bba7d36e0", null ],
    [ "cg_getstats", "adpcg_8c.html#a1c4e9fe4acfe20a78d506724b52f35ed", null ],
    [ "cg_init", "adpcg_8c.html#afdf40148d367eddfe46f567dd77a73d4", null ],
    [ "cg_iteration", "adpcg_8c.html#a3b56f427deb776b33651cf0e7d81daf8", null ],
    [ "cg_precondition", "adpcg_8c.html#a494a49c755f006b1b68e36421d3a5813", null ],
    [ "cg_prepare_preconditioner", "adpcg_8c.html#ae6125dc0de03090118780239204240b0", null ],
    [ "cg_register", "adpcg_8c.html#a8a9678238b3f2bef2c41c1430d8888e4", null ],
    [ "cg_setparam", "adpcg_8c.html#aa7a1177e034d6808f3925d74b19112ac", null ],
    [ "cg_solve", "adpcg_8c.html#a46ef15fb5a41405067fee03eb9ae4321", null ],
    [ "cg_start", "adpcg_8c.html#a1e35d6019ebca8db1a86da3f4d27ff76", null ],
    [ "my_clock", "adpcg_8c.html#a0a1279d668859155feec392d753f972a", null ]
];