var searchData=
[
  ['v_5falloc_0',['v_alloc',['../structadpcg.html#acf6c19b4c91e41e3083bdb0699e00968',1,'adpcg']]],
  ['v_5faxpby_1',['v_axpby',['../structadpcg.html#a472b11d7d504331724ba741d55b047d8',1,'adpcg']]],
  ['v_5faxpy_2',['v_axpy',['../structadpcg.html#ac22a6258c280f5870824175eeff3c60d',1,'adpcg']]],
  ['v_5fcopy_3',['v_copy',['../structadpcg.html#a491bba38109d637049ce6c5a62658a3d',1,'adpcg']]],
  ['v_5fdot_4',['v_dot',['../structadpcg.html#ac47bf7c3c78affdf894f730534dbcadc',1,'adpcg']]],
  ['v_5ffree_5',['v_free',['../structadpcg.html#a2aa9789618bcce938aa7986e216c1dcf',1,'adpcg']]],
  ['v_5finit_6',['v_init',['../structadpcg.html#ac81303e4b6c8f1782c13af03d074cc90',1,'adpcg']]],
  ['v_5fnorm_7',['v_norm',['../structadpcg.html#a3aaac9631e08e9e97c5bec740def7d8a',1,'adpcg']]],
  ['v_5freset_8',['v_reset',['../structadpcg.html#aa5b62ff4c2842e8dca233976aa2e7ac4',1,'adpcg']]],
  ['v_5fzaxpby_9',['v_zaxpby',['../structadpcg.html#a00eac37ac375ec76ede60477b6a6dbc7',1,'adpcg']]]
];
