var searchData=
[
  ['r_0',['r',['../structadpcg.html#a6890dff38b9f6172053da05e3aab78e9',1,'adpcg']]],
  ['restart_1',['restart',['../structadpcg.html#a783a672a4ef0d86410d99ef7276747cf',1,'adpcg']]],
  ['reuse_2',['reuse',['../structadpcg.html#af9ecdd5ed4c4d3ea3e46979a189bb39b',1,'adpcg']]],
  ['rnew_3',['rnew',['../structadpcg.html#a1fc468e191ab79f005eb16576a8ca86f',1,'adpcg']]],
  ['rnrm_4',['rnrm',['../structadpcg.html#a1ca83805524f8dd1ef51b86a4cb6cd63',1,'adpcg']]]
];
