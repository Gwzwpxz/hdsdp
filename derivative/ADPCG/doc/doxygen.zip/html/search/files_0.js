var searchData=
[
  ['adpcg_2ec_0',['adpcg.c',['../adpcg_8c.html',1,'']]],
  ['adpcg_2eh_1',['adpcg.h',['../adpcg_8h.html',1,'']]]
];
