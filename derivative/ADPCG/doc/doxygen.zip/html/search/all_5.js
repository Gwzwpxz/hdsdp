var searchData=
[
  ['maxiter_0',['maxiter',['../structadpcg.html#a33d14b5e68cc3e9bf715e488d081b7c5',1,'adpcg']]],
  ['my_5fclock_1',['my_clock',['../adpcg_8c.html#a0a1279d668859155feec392d753f972a',1,'adpcg.c']]]
];
