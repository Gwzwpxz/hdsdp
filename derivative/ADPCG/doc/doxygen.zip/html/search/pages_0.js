var searchData=
[
  ['design_20of_20an_20adaptive_20pre_2dconditioned_20cg_20solver_0',['Design of an adaptive pre-conditioned CG solver',['../index.html',1,'(Global Namespace)'],['../md__readme.html',1,'(Global Namespace)']]]
];
