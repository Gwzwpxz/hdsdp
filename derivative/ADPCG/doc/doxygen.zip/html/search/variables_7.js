var searchData=
[
  ['pinvr_0',['pinvr',['../structadpcg.html#a2a9458e35ce08a2464f09f1efc5d5456',1,'adpcg']]],
  ['ptype_1',['ptype',['../structadpcg.html#ac02cda33bccbc276880c14c29e21d05f',1,'adpcg']]]
];
