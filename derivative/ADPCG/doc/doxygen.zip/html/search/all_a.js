var searchData=
[
  ['tol_0',['tol',['../structadpcg.html#a2687e4b3cb5da7dbd00e565343f66c6c',1,'adpcg']]]
];
