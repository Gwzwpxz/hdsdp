var searchData=
[
  ['cg_5falloc_0',['cg_alloc',['../adpcg_8c.html#a6b92dfb6d54a82b6f8c1f4e7e5b765ce',1,'adpcg.c']]],
  ['cg_5fdecision_1',['cg_decision',['../adpcg_8c.html#a25344647e8c828d40c7584dd36675279',1,'adpcg.c']]],
  ['cg_5ffinish_2',['cg_finish',['../adpcg_8c.html#ab2db786b0a4ff73bc1090eb786f07b3a',1,'adpcg.c']]],
  ['cg_5ffree_3',['cg_free',['../adpcg_8c.html#a01232c348051ba27254a883bba7d36e0',1,'adpcg.c']]],
  ['cg_5fgetstats_4',['cg_getstats',['../adpcg_8c.html#a1c4e9fe4acfe20a78d506724b52f35ed',1,'adpcg.c']]],
  ['cg_5finit_5',['cg_init',['../adpcg_8c.html#afdf40148d367eddfe46f567dd77a73d4',1,'adpcg.c']]],
  ['cg_5fiteration_6',['cg_iteration',['../adpcg_8c.html#a3b56f427deb776b33651cf0e7d81daf8',1,'adpcg.c']]],
  ['cg_5fprecondition_7',['cg_precondition',['../adpcg_8c.html#a494a49c755f006b1b68e36421d3a5813',1,'adpcg.c']]],
  ['cg_5fprepare_5fpreconditioner_8',['cg_prepare_preconditioner',['../adpcg_8c.html#ae6125dc0de03090118780239204240b0',1,'adpcg.c']]],
  ['cg_5fregister_9',['cg_register',['../adpcg_8c.html#a8a9678238b3f2bef2c41c1430d8888e4',1,'adpcg.c']]],
  ['cg_5fsetparam_10',['cg_setparam',['../adpcg_8c.html#aa7a1177e034d6808f3925d74b19112ac',1,'adpcg.c']]],
  ['cg_5fsolve_11',['cg_solve',['../adpcg_8c.html#a46ef15fb5a41405067fee03eb9ae4321',1,'adpcg.c']]],
  ['cg_5fstart_12',['cg_start',['../adpcg_8c.html#a1e35d6019ebca8db1a86da3f4d27ff76',1,'adpcg.c']]]
];
