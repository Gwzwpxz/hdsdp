var searchData=
[
  ['maxiter_0',['maxiter',['../structadpcg.html#a33d14b5e68cc3e9bf715e488d081b7c5',1,'adpcg']]]
];
