var searchData=
[
  ['status_0',['status',['../structadpcg.html#ae0ff253278dce9e6391c400ce3c9f3f0',1,'adpcg']]]
];
