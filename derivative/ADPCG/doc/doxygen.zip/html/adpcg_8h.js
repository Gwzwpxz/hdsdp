var adpcg_8h =
[
    [ "adpcg", "structadpcg.html", "structadpcg" ],
    [ "CG_NO_PRECOND", "adpcg_8h.html#a1116125faacbbcc5075c88a4510740f0", null ],
    [ "CG_PRECOND_CHOL", "adpcg_8h.html#a21c2080832231539dce1e00cd8a2365f", null ],
    [ "CG_PRECOND_DIAG", "adpcg_8h.html#a791207da35af0f7509acd36c86403c6e", null ],
    [ "CG_STATUS_DIRECT", "adpcg_8h.html#ad4d207ffb28e2b94ddc94ce6234d6d05", null ],
    [ "CG_STATUS_FAILED", "adpcg_8h.html#ae2e377dfa5d495692a7441030dfb39b4", null ],
    [ "CG_STATUS_MAXITER", "adpcg_8h.html#a44f26b54fe220ecbbe30ebc77cb50621", null ],
    [ "CG_STATUS_SOLVED", "adpcg_8h.html#ad87dfa03b9f3085142f1ab89b3cdfb8d", null ],
    [ "CG_STATUS_UNKNOWN", "adpcg_8h.html#ab999d19e7c3ccba6c2e8cd654229c312", null ]
];