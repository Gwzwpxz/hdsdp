var annotated_dup =
[
    [ "adpcg", "structadpcg.html", "structadpcg" ]
];